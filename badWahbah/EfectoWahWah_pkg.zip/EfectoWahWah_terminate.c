/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * EfectoWahWah_terminate.c
 *
 * Code generation for function 'EfectoWahWah_terminate'
 *
 */

/* Include files */
#include "EfectoWahWah_terminate.h"
#include "rt_nonfinite.h"

/* Function Definitions */
void EfectoWahWah_terminate(void)
{
}

/* End of code generation (EfectoWahWah_terminate.c) */
