/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * EfectoWahWah_initialize.c
 *
 * Code generation for function 'EfectoWahWah_initialize'
 *
 */

/* Include files */
#include "EfectoWahWah_initialize.h"
#include "rt_nonfinite.h"

/* Function Definitions */
void EfectoWahWah_initialize(void)
{
}

/* End of code generation (EfectoWahWah_initialize.c) */
